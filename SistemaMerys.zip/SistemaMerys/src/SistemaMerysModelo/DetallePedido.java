package SistemaMerysModelo;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class DetallePedido {
    private int idDetallePedido;
    private int idPedido;
    private int cantidadTotalProductos;
    private float total;

    // Constructor
    public DetallePedido(){}
    public DetallePedido(int idDetallePedido, int idPedido, int cantidadTotalProductos, float total) {
        this.idDetallePedido = idDetallePedido;
        this.idPedido = idPedido;
        this.cantidadTotalProductos = cantidadTotalProductos;
        this.total = total;
    }

    public int getIdDetallePedido() {
        return idDetallePedido;
    }

    public void setIdDetallePedido(int idDetallePedido) {
        this.idDetallePedido = idDetallePedido;
    }

    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public int getCantidadTotalProductos() {
        return cantidadTotalProductos;
    }

    public void setCantidadTotalProductos(int cantidadTotalProductos) {
        this.cantidadTotalProductos = cantidadTotalProductos;
    }

    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }
   

    public void registrarDetallePedido() {
        Conexion conexion = new Conexion();
        Connection con = conexion.getConnection();
        try {
            String query = "INSERT INTO detalle_pedido (idDetallePedido, idPedido, cantidadTotalProductos, total) VALUES (?, ?, ?, ?)";
            PreparedStatement preparedStatement = con.prepareStatement(query);
            preparedStatement.setInt(1, idPedido);
            preparedStatement.setInt(2, cantidadTotalProductos);
            preparedStatement.setFloat(3, total);
            
            preparedStatement.executeUpdate();
            System.out.println("Detalle de pedido registrado en la base de datos");
        } catch (SQLException e) {
            System.err.println("Error al insertar en la base de datos: " + e.getMessage());
        }
    }    
}
