package SistemaMerysModelo;
import Conexion.Conexion;
import SistemaMerysVista.PagMenuPrincipal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
public class Login extends Usuario{

    public Login() {
    }
    
    Conexion conexion = new Conexion();
    Connection con = conexion.getConnection();
    
    public Login(int idUsuario, String nombre_usuario, String correo, String contraseña) {
        super(idUsuario, nombre_usuario, correo, contraseña);
    }
    
    public Usuario validarLogin(String nombreUsuario, String contraseña) throws SQLException {

        String sql = "SELECT * FROM usuario WHERE nombreUsuario = ? AND contraseña = ?";
        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, nombreUsuario);
            stmt.setString(2, contraseña);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Usuario usuario = new Usuario();
                    usuario.setIdUsuario(rs.getInt("idUsuario"));
                    usuario.setNombre_usuario(rs.getString("nombreUsuario"));
                    usuario.setContraseña(rs.getString("contraseña"));
                    usuario.setCorreo(rs.getString("correo"));
                    return usuario;
                } else {
                    return null; // Usuario no encontrado
                }
            }
        }
    }
    public Empleado obtenerEmpleadoPorIdUsuario(int idUsuario) throws SQLException {
        String sql = "SELECT * FROM empleado WHERE idUsuario = ?";
        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, idUsuario);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Empleado empleado = new Empleado();
                    empleado.setIdEmpleado(rs.getInt("idEmpleado"));
                    empleado.setIdCargoEmpleado(rs.getInt("idCargoEmpleado"));
                    empleado.setIdUsuario(rs.getInt("idUsuario"));
                    empleado.setNombre(rs.getString("nombreEmp"));
                    empleado.setApellido(rs.getString("apellidoEmp"));
                    empleado.setTelefono(rs.getString("telefonoEmp"));
                    empleado.setEdad(rs.getInt("edad"));
                    empleado.setDNI(rs.getString("DNI"));
                    return empleado;
                } else {
                    return null; 
                }
            }
        }
    }

    public String obtenerCargoPorIdCargoEmpleado(int idCargoEmpleado) throws SQLException {
        String sql = "SELECT cargoEmpleado FROM cargo_empleado WHERE idCargoEmpleado = ?";
        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, idCargoEmpleado);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("cargoEmpleado");
                } else {
                    return null; 
                }
            }
        }
    }
    
    
    public boolean verificarCredenciales(String usuario, String contraseña) {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();
            boolean verificado = false;

            String sql = "SELECT * FROM Usuario WHERE nombreUsuario = ? AND contraseña = ?";

            try {
                PreparedStatement statement = conn.prepareStatement(sql);
                statement.setString(1, usuario);
                statement.setString(2, contraseña);
                ResultSet rs = statement.executeQuery();

                if (rs.next()) {
                    verificado = true;
                }

                rs.close();
                statement.close();
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return verificado;
        }
}
