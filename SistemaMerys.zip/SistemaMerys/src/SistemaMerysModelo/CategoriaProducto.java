package SistemaMerysModelo;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CategoriaProducto {
    
    private int idCategoriaProducto;
    private String categoriaProducto;
    private String descripcionProducto;
    
    public CategoriaProducto(){}

    public CategoriaProducto(int idCategoriaProducto, String categoriaProducto, String descripcionProducto) {
        this.idCategoriaProducto = idCategoriaProducto;
        this.categoriaProducto = categoriaProducto;
        this.descripcionProducto = descripcionProducto;
    }

    public int getIdCategoriaProducto() {
        return idCategoriaProducto;
    }

    public void setIdCategoriaProducto(int idCategoriaProducto) {
        this.idCategoriaProducto = idCategoriaProducto;
    }

    public String getCategoriaProducto() {
        return categoriaProducto;
    }

    public void setCategoriaProducto(String categoriaProducto) {
        this.categoriaProducto = categoriaProducto;
    }

    public String getDescripcionProducto() {
        return descripcionProducto;
    }

    public void setDescripcionProducto(String descripcionProducto) {
        this.descripcionProducto = descripcionProducto;
    }
    
    public void registrarCategoria(){
        Conexion conexion = new Conexion();
        Connection con = conexion.getConnection();
        try{
            String sqlCategoria = "INSERT INTO categoria_producto(categoriaProducto, descripcionProducto) VALUES (?, ?) ";               
            try(PreparedStatement preparedStatement = con.prepareStatement(sqlCategoria, PreparedStatement.RETURN_GENERATED_KEYS)){
                preparedStatement.setString(1, categoriaProducto);
                preparedStatement.setString(2, descripcionProducto);
                preparedStatement.executeUpdate();
                
                ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    idCategoriaProducto = generatedKeys.getInt(1);
                }
            }
            System.out.println("Categoria del Producto registrado en la base de datos");
        } catch (SQLException e) {
            System.err.println("Error al insertar en la base de datos: " + e.getMessage());
        }
    }
    
    public static CategoriaProducto consultarCategoria(int idCategoriaProducto){
        Conexion conexion = new Conexion();
        String query = "SELECT * FROM categoria_producto WHERE idCategoriaProducto = ?";
        
        try (PreparedStatement preparedStatement = conexion.getConnection().prepareStatement(query)){
        preparedStatement.setInt(1, idCategoriaProducto);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    String categoriaProducto = resultSet.getString("categoriaProducto");
                    String descripcionProducto = resultSet.getString("descripcionProducto");

                    return new CategoriaProducto(idCategoriaProducto, categoriaProducto, descripcionProducto);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar Producto en la base de datos: " + e.getMessage());
        }
        return null;
    }
    
    public void eliminarCategoria() {
        Conexion conexion = new Conexion();
        Connection conn = conexion.getConnection();

        try {
            String query = "DELETE FROM categoria_producto WHERE idCategoriaProducto = ?";
            try (PreparedStatement preparedStatement = conn.prepareStatement(query)) {
                preparedStatement.setInt(1, idCategoriaProducto);
                preparedStatement.executeUpdate();
                System.out.println("Categoria producto eliminado de la base de datos");
            }
        } catch (SQLException e) {
            System.err.println("Error al eliminar categoria del producto de la base de datos: " + e.getMessage());
        }
    }

    public void actualizarCategoria(){
        Conexion conexion = new Conexion();
        Connection conn = conexion.getConnection();

        try {
            String query = "UPDATE categoria_producto SET categoriaProducto = ?, descripcionProducto = ? WHERE idCategoriaProducto = ?";
            try (PreparedStatement preparedStatement = conn.prepareStatement(query)) {
                preparedStatement.setString(1, categoriaProducto);
                preparedStatement.setString(2, descripcionProducto); 
                preparedStatement.setInt(3, idCategoriaProducto); 
                preparedStatement.executeUpdate();
            }
            System.out.println("Categoria producto actualizado correctamente en la base de datos");
        } catch (SQLException e) {
            System.err.println("Error al actualizar la categoria producto en la base de datos: " + e.getMessage());
        }
    }    
}
