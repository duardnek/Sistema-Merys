package SistemaMerysModelo;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CargoEmpleado {

    private int idCargoEmpleado;
    private String cargoEmpleado;
    
    
    public CargoEmpleado(){
    }
    public CargoEmpleado(int idCargoEmpleado, String cargoEmpleado) {
        this.idCargoEmpleado = idCargoEmpleado;
        this.cargoEmpleado = cargoEmpleado;
    }

    public int getIdCargoEmpleado() {
        return idCargoEmpleado;
    }

    public void setIdCargoEmpleado(int idCargoEmpleado) {
        this.idCargoEmpleado = idCargoEmpleado;
    }

    public String getCargoEmpleado() {
        return cargoEmpleado;
    }

    public void setCargoEmpleado(String cargoEmpleado) {
        this.cargoEmpleado = cargoEmpleado;
    }

    public void registrarCargoEmpleado() {
        Conexion conexion = new Conexion();
        Connection conn = conexion.getConnection();

        try {
            String sql = "INSERT INTO Cargo_Empleado (cargoEmpleado) VALUES (?)";
            try (PreparedStatement preparedStatement = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
                preparedStatement.setString(1, cargoEmpleado);
                preparedStatement.executeUpdate();

                ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    idCargoEmpleado = generatedKeys.getInt(1);
                }
            }
            System.out.println("Cargo empleado registrado en la base de datos");
        } catch (SQLException e) {
            System.err.println("Error al insertar cargo empleado en la base de datos: " + e.getMessage());
        }
    }
    
      public static CargoEmpleado consultarCargo(int idCargoEmpleado) {
        Conexion conexion = new Conexion();
        String query = "SELECT*FROM Cargo_Empleado WHERE idCargoEmpleado = ?";
        
        try (PreparedStatement preparedStatement = conexion.getConnection().prepareStatement(query)) {
                preparedStatement.setInt(1, idCargoEmpleado);
                
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                    String cargoEmpleado = resultSet.getString("cargoEmpleado");
                    
                    return new CargoEmpleado(idCargoEmpleado, cargoEmpleado);               
                    }
                }    
        } catch (SQLException e) {
            System.err.println("Error al consultar el cargo en la base de datos: " + e.getMessage());
        }
        return null;
    }
      
    public void eliminarCargoEmpleado() {
        Conexion conexion = new Conexion();
        Connection conn = conexion.getConnection();

        try {
            String sql = "DELETE FROM Cargo_Empleado WHERE idCargoEmpleado = ?";
            try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
                preparedStatement.setInt(1, idCargoEmpleado);
                preparedStatement.executeUpdate();
                System.out.println("Cargo empleado eliminado de la base de datos");
            }
        } catch (SQLException e) {
            System.err.println("Error al eliminar cargo empleado de la base de datos: " + e.getMessage());
        }
    }
    
    public void actualizarCargoEmpleado() {
        Conexion conexion = new Conexion();
        Connection conn = conexion.getConnection();

        try {
            String sql = "UPDATE Cargo_Empleado SET cargoEmpleado = ? WHERE idCargoEmpleado = ?";
            try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
                preparedStatement.setString(1, cargoEmpleado);
                preparedStatement.setInt(2, idCargoEmpleado); // Asegúrate de que idCargoEmpleado es el último parámetro
                preparedStatement.executeUpdate();
            }
            System.out.println("Cargo empleado actualizado correctamente en la base de datos");
        } catch (SQLException e) {
            System.err.println("Error al actualizar cargo empleado en la base de datos: " + e.getMessage());
        }
    }
}
