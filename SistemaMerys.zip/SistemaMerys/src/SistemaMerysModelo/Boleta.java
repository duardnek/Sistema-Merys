
package SistemaMerysModelo;

public class Boleta {
    
}
