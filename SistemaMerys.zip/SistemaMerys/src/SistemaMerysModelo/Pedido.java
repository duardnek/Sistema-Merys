package SistemaMerysModelo;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

public class Pedido {
    private int idPedido;
    private int idProducto;
    private int idEmpleado;
    private int idCliente;
    private String fechaPedido;
    private int numMesa;
    private String estadoPedido;
    private String descripcionPedido;
    private String tipoPedido;
    private int cantidadProducto;
    private float precioUnitario;

    // Constructor vacío
    public Pedido() {
    }

    // Constructor con todos los atributos
    public Pedido(int idPedido, int idProducto, int idEmpleado, int idCliente, String fechaPedido, int numMesa,
                  String estadoPedido, String descripcionPedido, String tipoPedido, int cantidadProducto, float precioUnitario) {
        this.idPedido = idPedido;
        this.idProducto = idProducto;
        this.idEmpleado = idEmpleado;
        this.idCliente = idCliente;
        this.fechaPedido = fechaPedido;
        this.numMesa = numMesa;
        this.estadoPedido = estadoPedido;
        this.descripcionPedido = descripcionPedido;
        this.tipoPedido = tipoPedido;
        this.cantidadProducto = cantidadProducto;
        this.precioUnitario = precioUnitario;
    }

    // Métodos getters y setters
    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getFechaPedido() {
        return fechaPedido;
    }

    public void setFechaPedido(String fechaPedido) {
        this.fechaPedido = fechaPedido;
    }

    public int getNumMesa() {
        return numMesa;
    }

    public void setNumMesa(int numMesa) {
        this.numMesa = numMesa;
    }

    public String getEstadoPedido() {
        return estadoPedido;
    }

    public void setEstadoPedido(String estadoPedido) {
        this.estadoPedido = estadoPedido;
    }

    public String getDescripcionPedido() {
        return descripcionPedido;
    }

    public void setDescripcionPedido(String descripcionPedido) {
        this.descripcionPedido = descripcionPedido;
    }

    public String getTipoPedido() {
        return tipoPedido;
    }

    public void setTipoPedido(String tipoPedido) {
        this.tipoPedido = tipoPedido;
    }

    public int getCantidadProducto() {
        return cantidadProducto;
    }

    public void setCantidadProducto(int cantidadProducto) {
        this.cantidadProducto = cantidadProducto;
    }

    public float getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(float precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public void registrarPedido() {
        Conexion conexion = new Conexion();
        Connection con = conexion.getConnection();
        try {
            String query = "INSERT INTO Pedido (idProducto, idEmpleado, idCliente, fechaPedido, numMesa, estadoPedido, descripcionPedido, tipoPedido, cantidadProducto, precioUnitario) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = con.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS)) {
            preparedStatement.setInt(1, idProducto);
            preparedStatement.setInt(2, idEmpleado);
            preparedStatement.setInt(3, idCliente);
            preparedStatement.setString(4, fechaPedido);
            preparedStatement.setInt(5, numMesa);
            preparedStatement.setString(6, estadoPedido);
            preparedStatement.setString(7, descripcionPedido);
            preparedStatement.setString(8, tipoPedido);
            preparedStatement.setInt(9, cantidadProducto);
            preparedStatement.setFloat(10, precioUnitario);
            preparedStatement.executeUpdate();
            ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    idPedido = generatedKeys.getInt(1);
            }            
            System.out.println("Pedido registrado en la base de datos.");
            }
        } catch (SQLException e) {
            System.err.println("Error al insertar pedido: " + e.getMessage());
        } 
    }
    
    
    public void verDatosCarrito(DefaultTableModel modeloTablaCarrito) {
        Conexion conexion = new Conexion();
        int contador = 1; 

        try {
            String query = "SELECT * FROM vista_carrito_pedido";
            try (PreparedStatement preparedStatement = conexion.getConnection().prepareStatement(query);
                 ResultSet resultSet = preparedStatement.executeQuery()) {

                modeloTablaCarrito.setRowCount(0);

                while (resultSet.next()) {
                    cantidadProducto = resultSet.getInt("Cantidad");
                    String nombreProd = resultSet.getString("Nombre");
                    precioUnitario = resultSet.getFloat("Total");

                    Object[] fila = {contador, cantidadProducto, nombreProd, precioUnitario};
                    modeloTablaCarrito.addRow(fila);
                    contador++; 
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener los datos de la base de datos: " + e.getMessage());
        }
    }
    
public void verDatosPedidosDisponibles(DefaultTableModel modeloTablaPedidos) {
    Conexion conexion = new Conexion();
    try {
        String query = "SELECT * FROM vista_pedidos_disponibles";
        try (PreparedStatement preparedStatement = conexion.getConnection().prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            modeloTablaPedidos.setRowCount(0);  
            
            while (resultSet.next()) {
                idPedido = resultSet.getInt("ID");
                String estadoPedido = resultSet.getString("Estado");
                numMesa = resultSet.getInt("Mesa");
                String nombreProd = resultSet.getString("Producto"); 
                String nombreCliente = resultSet.getString("Cliente");
                String tipoPedido = resultSet.getString("Tipo");
                String nombreEmp = resultSet.getString("Empleado");
                String fechaPedido = resultSet.getString("Fecha");

                Object[] fila = {idPedido, estadoPedido, numMesa, nombreProd, nombreCliente, tipoPedido, nombreEmp, fechaPedido};
                modeloTablaPedidos.addRow(fila);
            }
        }
    } catch (SQLException e) {
        System.err.println("Error al obtener los datos de la base de datos: " + e.getMessage());
    }
}


    public void eliminarPedido() {
        Conexion conexion = new Conexion();
        Connection con = conexion.getConnection();
        try {
            String query = "DELETE FROM pedido WHERE idPedido=?";
            try (PreparedStatement preparedStatement = con.prepareStatement(query)) {
                preparedStatement.setInt(1, idPedido);
                preparedStatement.executeUpdate();
                System.out.println("Pedido eliminado de la base de datos.");
            }
        } catch (SQLException e) {
            System.err.println("Error al eliminar pedido: " + e.getMessage());
        }
    }

    public void actualizarPedido() {
        Conexion conexion = new Conexion();
        try {
            String query = "UPDATE pedido SET idProducto=?, idEmpleado=?, idCliente=?, fechaPedido=?, numMesa=?, estadoPedido=?, descripcionPedido=?, tipoPedido=?, cantidadProducto=?, precioUnitario=? "
                    + "WHERE idPedido=?";
            try (PreparedStatement preparedStatement = conexion.getConnection().prepareStatement(query)) {    
            preparedStatement.setInt(1, idProducto);
            preparedStatement.setInt(2, idEmpleado);
            preparedStatement.setInt(3, idCliente);
            preparedStatement.setString(4, fechaPedido);
            preparedStatement.setInt(5, numMesa);
            preparedStatement.setString(6, estadoPedido);
            preparedStatement.setString(7, descripcionPedido);
            preparedStatement.setString(8, tipoPedido);
            preparedStatement.setInt(9, cantidadProducto);
            preparedStatement.setFloat(10, precioUnitario);
            preparedStatement.setInt(11, idPedido);
            preparedStatement.executeUpdate();
            System.out.println("Pedido actualizado en la base de datos.");
            }
        } catch (SQLException e) {
            System.err.println("Error al actualizar pedido: " + e.getMessage());
        }
    }

}