package SistemaMerysModelo;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

public class Producto {
    
    private int idProducto;
    private int idCategoriaProducto;
    private String nombreProd;
    private float precioUnitario;
    
    public Producto(){}

    public Producto(int idProducto, int idCategoriaProducto, String nombreProd, float precioUnitario) {
        this.idProducto = idProducto;
        this.idCategoriaProducto = idCategoriaProducto;
        this.nombreProd = nombreProd;
        this.precioUnitario = precioUnitario;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public int getIdCategoriaProducto() {
        return idCategoriaProducto;
    }

    public void setIdCategoriaProducto(int idCategoriaProducto) {
        this.idCategoriaProducto = idCategoriaProducto;
    }

    public String getNombreProd() {
        return nombreProd;
    }

    public void setNombreProd(String nombreProd) {
        this.nombreProd = nombreProd;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(float precioUnitario) {
        this.precioUnitario = precioUnitario;
    }
    
    public void registrarProducto(){
        Conexion conexion = new Conexion();
        Connection con = conexion.getConnection();        
        try {
            String sqlProducto = "INSERT INTO Producto (idCategoriaProducto, nombreProd, precioUnitario) VALUES (?, ?, ?)";
            try (PreparedStatement preparedStatement = con.prepareStatement(sqlProducto)) {
                preparedStatement.setInt(1, idCategoriaProducto);
                preparedStatement.setString(2, nombreProd);
                preparedStatement.setFloat(3, precioUnitario);
                preparedStatement.executeUpdate();
            }
            System.out.println("Producto registrado en la base de datos");
        } catch (SQLException e) {
            System.err.println("Error al insertar en la base de datos: " + e.getMessage());
        }
    }
    
    public void verDatosProducto(DefaultTableModel modeloTablaProducto){
        Conexion conexion = new Conexion();
        try {
            String query = "SELECT * FROM vista_productos_categoria"; 
            try (PreparedStatement preparedStatement = conexion.getConnection().prepareStatement(query);
                 ResultSet resultSet = preparedStatement.executeQuery()) {

                modeloTablaProducto.setRowCount(0); 
                
                while (resultSet.next()) {
                    idProducto = resultSet.getInt("idProducto");
                    nombreProd = resultSet.getString("nombreProd");                    
                    String categoriaProducto = resultSet.getString("categoriaProducto");
                    String descripcionProducto = resultSet.getString("descripcionProducto");
                    precioUnitario = resultSet.getFloat("precioUnitario");

                    Object[] fila = {idProducto, nombreProd, categoriaProducto, descripcionProducto, precioUnitario};
                    modeloTablaProducto.addRow(fila);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener los datos de la base de datos: " + e.getMessage());
        }
    }
    
    public Producto consultarProducto(int idProducto){
        Conexion conexion = new Conexion();
        String query = "SELECT * FROM Producto WHERE idProducto = ?";
        
        try (PreparedStatement preparedStatement = conexion.getConnection().prepareStatement(query)){
        preparedStatement.setInt(1, idProducto);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    idCategoriaProducto = resultSet.getInt("idCategoriaProducto");
                    nombreProd = resultSet.getString("nombreProd");
                    precioUnitario = resultSet.getFloat("precioUnitario");

                    return new Producto(idProducto, idCategoriaProducto, nombreProd, precioUnitario);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar Producto en la base de datos: " + e.getMessage());
        }
        return null;
    }
    
    public void eliminarProducto(){
        Conexion conexion = new Conexion();
        Connection conn = conexion.getConnection();

        try {
            String query = "DELETE FROM Producto WHERE idProducto = ?";
            try (PreparedStatement preparedStatement = conn.prepareStatement(query)) {
                preparedStatement.setInt(1, idProducto);
                preparedStatement.executeUpdate();
                System.out.println("Producto eliminado de la base de datos");
            }
        } catch (SQLException e) {
            System.err.println("Error al eliminar el producto de la base de datos: " + e.getMessage());
        }        
    }
    
    public void actualizarProducto(){
        Conexion conexion = new Conexion();
        try {
            String query = "UPDATE Producto SET idCategoriaProducto = ?, nombreProd = ?, precioUnitario = ? WHERE idProducto = ?";
            try (PreparedStatement preparedStatement = conexion.getConnection().prepareStatement(query)) {
                preparedStatement.setInt(1, idCategoriaProducto);
                preparedStatement.setString(2, nombreProd);
                preparedStatement.setFloat(3, precioUnitario);
                preparedStatement.setInt(4, idProducto);
                preparedStatement.executeUpdate();
                }
                System.out.println("Producto actualizado correctamente en la base de datos");
            } catch (SQLException e) {
                System.err.println("Error al actualizar el Producto en la base de datos: " + e.getMessage());
            }        
    }
    
   
}
