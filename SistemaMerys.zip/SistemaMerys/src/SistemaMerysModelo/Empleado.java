package SistemaMerysModelo;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

public class Empleado extends Persona {

    public int idEmpleado;
    private int idCargoEmpleado;
    private int idUsuario;
    private int edad;
    private String DNI;
        public Empleado() {
    }
    public Empleado(int idEmpleado, int idCargoEmpleado, int idUsuario, String nombre, String apellido, String telefono, int edad, String DNI) {
        super(nombre, apellido, telefono);
        this.idEmpleado = idEmpleado;
        this.idCargoEmpleado = idCargoEmpleado;
        this.idUsuario = idUsuario;
        this.edad = edad;
        this.DNI = DNI;
    }
    
    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String getApellido() {
        return apellido;
    }

    @Override
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    @Override
    public String getTelefono() {
        return telefono;
    }

    @Override
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public int getIdCargoEmpleado() {
        return idCargoEmpleado;
    }

    public void setIdCargoEmpleado(int idCargoEmpleado) {
        this.idCargoEmpleado = idCargoEmpleado;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }    

    public void registrarEmpleado() {
        Conexion conexion = new Conexion();
        Connection con = conexion.getConnection();

        try {
            String sqlEmpleado = "INSERT INTO Empleado (idCargoEmpleado, idUsuario, nombreEmp, apellidoEmp, telefonoEmp, edad, DNI) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = con.prepareStatement(sqlEmpleado)) {
                preparedStatement.setInt(1, idCargoEmpleado);
                preparedStatement.setInt(2, idUsuario);
                preparedStatement.setString(3, nombre);
                preparedStatement.setString(4, apellido);
                preparedStatement.setString(5, telefono);
                preparedStatement.setInt(6, edad);
                preparedStatement.setString(7, DNI);
                preparedStatement.executeUpdate();
            }
            System.out.println("Empleado registrado en la base de datos");
        } catch (SQLException e) {
            System.err.println("Error al insertar en la base de datos: " + e.getMessage());
        }
    }
    
    public void verDatosEmpleado(DefaultTableModel modeloTablaEmpleado) {
        Conexion conexion = new Conexion();
        try {
            String query = "SELECT * FROM vista_empleado_usuario_cargo"; 
            try (PreparedStatement preparedStatement = conexion.getConnection().prepareStatement(query);
                 ResultSet resultSet = preparedStatement.executeQuery()) {

                modeloTablaEmpleado.setRowCount(0); 

                while (resultSet.next()) {
                    idEmpleado = resultSet.getInt("idEmpleado");
                    String cargo = resultSet.getString("cargo");
                    String usuario = resultSet.getString("usuario");
                    String contraseña = resultSet.getString("contraseña");
                    String correo = resultSet.getString("correo");
                    nombre = resultSet.getString("nombre");
                    apellido = resultSet.getString("apellido");
                    telefono = resultSet.getString("telefono");
                    edad = resultSet.getInt("edad");
                    DNI = resultSet.getString("DNI");

                    Object[] fila = {idEmpleado, cargo, usuario, contraseña, correo, nombre, apellido, telefono, edad, DNI};
                    modeloTablaEmpleado.addRow(fila);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener los datos de la base de datos: " + e.getMessage());
        }
    }
    
    public Empleado consultarEmpleado(int idEmpleado) {
        Conexion conexion = new Conexion();
        String query = "SELECT * FROM Empleado WHERE idEmpleado = ?";
        
        try (PreparedStatement preparedStatement = conexion.getConnection().prepareStatement(query)){
        preparedStatement.setInt(1, idEmpleado);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    idCargoEmpleado = resultSet.getInt("idCargoEmpleado");
                    idUsuario = resultSet.getInt("idUsuario");
                    nombre = resultSet.getString("nombreEmp");
                    apellido = resultSet.getString("apellidoEmp");
                    telefono = resultSet.getString("telefonoEmp");
                    edad = resultSet.getInt("edad");
                    DNI = resultSet.getString("DNI");

                    return new Empleado(idEmpleado, idCargoEmpleado, idUsuario, nombre, apellido, telefono, edad, DNI);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar empleado en la base de datos: " + e.getMessage());
        }
        return null;
    }
    
    public void eliminarEmpleado() {
        Conexion conexion = new Conexion();
        Connection conn = conexion.getConnection();

        try {
            String sql = "DELETE FROM Empleado WHERE idEmpleado = ?";
            try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
                preparedStatement.setInt(1, idEmpleado);
                preparedStatement.executeUpdate();
                System.out.println("Empleado eliminado de la base de datos");
            }
        } catch (SQLException e) {
            System.err.println("Error al eliminar empleado de la base de datos: " + e.getMessage());
        }
    }

    public void actualizarEmpleado() {
    Conexion conexion = new Conexion();
        try {
            String query = "UPDATE Empleado SET idCargoEmpleado = ?, idUsuario = ?, nombreEmp = ?, apellidoEmp = ?, telefonoEmp = ?, edad = ?, DNI = ? WHERE idEmpleado = ?";
            try (PreparedStatement preparedStatement = conexion.getConnection().prepareStatement(query)) {
                preparedStatement.setInt(1, idCargoEmpleado);
                preparedStatement.setInt(2, idUsuario);
                preparedStatement.setString(3, nombre);
                preparedStatement.setString(4, apellido);
                preparedStatement.setString(5, telefono);
                preparedStatement.setInt(6, edad);
                preparedStatement.setString(7, DNI);
                preparedStatement.setInt(8, idEmpleado); // Asegúrate de que idEmpleado es el último parámetro
                preparedStatement.executeUpdate();
            }
            System.out.println("Empleado actualizado correctamente en la base de datos");
        } catch (SQLException e) {
            System.err.println("Error al actualizar empleado en la base de datos: " + e.getMessage());
        }
    }


}

