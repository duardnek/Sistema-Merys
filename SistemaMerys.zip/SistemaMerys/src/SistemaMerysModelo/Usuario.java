package SistemaMerysModelo;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Usuario {

    private int idUsuario;
    private String nombre_usuario;
    private String correo;
    private String contraseña;
    
    public Usuario(){
    }
    public Usuario(int idUsuario, String nombre_usuario, String correo, String contraseña) {
        this.idUsuario = idUsuario;
        this.nombre_usuario = nombre_usuario;
        this.correo = correo;
        this.contraseña = contraseña;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNombre_usuario() {
        return nombre_usuario;
    }

    public void setNombre_usuario(String nombre_usuario) {
        this.nombre_usuario = nombre_usuario;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public void registrarUsuario() {
        Conexion conexion = new Conexion();
        Connection conn = conexion.getConnection();

        try {
            String sql = "INSERT INTO Usuario (nombreUsuario, correo, contraseña) VALUES (?, ?, ?)";
            try (PreparedStatement preparedStatement = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
                preparedStatement.setString(1, nombre_usuario);
                preparedStatement.setString(2, correo);
                preparedStatement.setString(3, contraseña);
                preparedStatement.executeUpdate();

                ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    idUsuario = generatedKeys.getInt(1);
                }
            }
            System.out.println("Usuario registrado en la base de datos");
        } catch (SQLException e) {
            System.err.println("Error al insertar usuario en la base de datos: " + e.getMessage());
        }
    }
    
    public static Usuario consultarUsuario(int idUsuario) {
        Conexion conexion = new Conexion();
        String query = "SELECT*FROM usuario WHERE idUsuario = ?";

        try (PreparedStatement preparedStatement = conexion.getConnection().prepareStatement(query)){
            preparedStatement.setInt(1, idUsuario);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    String nombreUsuario = resultSet.getString("nombreUsuario");
                    String contraseña = resultSet.getString("contraseña");
                    String correo = resultSet.getString("correo");

                    return new Usuario(idUsuario, nombreUsuario, correo, contraseña);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar el usuario en la base de datos: " + e.getMessage());
        }
        return null;
    }
    
    public void eliminarUsuario() {
        Conexion conexion = new Conexion();
        Connection conn = conexion.getConnection();

        try {
            String sql = "DELETE FROM Usuario WHERE idUsuario = ?";
            try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
                preparedStatement.setInt(1, idUsuario);
                preparedStatement.executeUpdate();
                System.out.println("Usuario eliminado de la base de datos");
            }
        } catch (SQLException e) {
            System.err.println("Error al eliminar usuario de la base de datos: " + e.getMessage());
        }
    }

    public void actualizarUsuario() {
        Conexion conexion = new Conexion();
        Connection conn = conexion.getConnection();

        try {
            String sql = "UPDATE Usuario SET nombreUsuario = ?, correo = ?, contraseña = ? WHERE idUsuario = ?";
            try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
                preparedStatement.setString(1, nombre_usuario);
                preparedStatement.setString(2, correo);
                preparedStatement.setString(3, contraseña);
                preparedStatement.setInt(4, idUsuario); // Asegúrate de que idUsuario es el último parámetro
                preparedStatement.executeUpdate();
            }
            System.out.println("Usuario actualizado correctamente en la base de datos");
        } catch (SQLException e) {
            System.err.println("Error al actualizar usuario en la base de datos: " + e.getMessage());
        }
    }
    

}
