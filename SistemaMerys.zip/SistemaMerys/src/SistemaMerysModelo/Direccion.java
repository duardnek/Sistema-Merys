package SistemaMerysModelo;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Direccion {
    private int idDireccion;
    private String calle;
    private String descripcionDireccion;
    private String distrito;

    public Direccion(int idDireccion, String calle, String descripcionDireccion, String distrito) {
        this.idDireccion = idDireccion;
        this.calle = calle;
        this.descripcionDireccion = descripcionDireccion;
        this.distrito = distrito;
    }

    public int getIdDireccion() {
        return idDireccion;
    }

    public void setIdDireccion(int idDireccion) {
        this.idDireccion = idDireccion;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getDescripcionDireccion() {
        return descripcionDireccion;
    }

    public void setDescripcionDireccion(String descripcionDireccion) {
        this.descripcionDireccion = descripcionDireccion;
    }

    public String getDistrito() {
        return distrito;
    }

    public void setDistrito(String distrito) {
        this.distrito = distrito;
    }
    
    public void registrarDireccion() {
        Conexion conexion = new Conexion();
        Connection con = conexion.getConnection();
        try {
            String query = "INSERT INTO direccion (calle, descripcionDireccion, distrito) VALUES (?, ?, ?)";
            try (PreparedStatement preparedStatement = con.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS)) {
                preparedStatement.setString(1, calle);
                preparedStatement.setString(2, descripcionDireccion);
                preparedStatement.setString(3, distrito);
                preparedStatement.executeUpdate();
                ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    idDireccion = generatedKeys.getInt(1);
                }
            }
            System.out.println("Direccion registrada en la base de datos");
        } catch (SQLException e) {
            System.err.println("Error al insertar en la base de datos: " + e.getMessage());
        }
    }
}
