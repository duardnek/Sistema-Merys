package Main;

import SistemaMerysControlador.LoginControlador;
import SistemaMerysModelo.Login;
import SistemaMerysVista.PagLogin;

public class Main {
    public static void main(String[] args) {
        
        Login login= new Login();
        PagLogin pagLogin = new PagLogin();
         
        LoginControlador loginControlador = new LoginControlador(pagLogin, login);
        loginControlador.iniciarLogin();
        
    }
}
