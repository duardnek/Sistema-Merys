package SistemaMerysControlador;

import SistemaMerysModelo.CategoriaProducto;
import SistemaMerysModelo.Producto;
import SistemaMerysVista.PagGestionarProducto;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class GestionarProductoControl implements ActionListener{
    
    private PagGestionarProducto vistaProducto;
    private Producto modeloProducto;
    private CategoriaProducto modeloCategoria;

    public GestionarProductoControl(PagGestionarProducto vistaProducto, Producto modeloProducto, CategoriaProducto modeloCategoria) {
        this.vistaProducto = vistaProducto;
        this.modeloProducto = modeloProducto;
        this.modeloCategoria = modeloCategoria;
        this.vistaProducto.jBGuardarProducto.addActionListener(this);
        this.vistaProducto.jBBuscarProducto.addActionListener(this);
        this.vistaProducto.jBEliminarProducto.addActionListener(this);
        this.vistaProducto.jBActualizarProducto.addActionListener(this);
        this.vistaProducto.jBLimpiar.addActionListener(this);
        
    }
    
    public void iniciarProducto(){ 
        vistaProducto.setTitle("Gestión de Producto");
        DefaultTableModel modeloTablaProducto = (DefaultTableModel) vistaProducto.jTProductos.getModel();
        modeloProducto.verDatosProducto(modeloTablaProducto);
        habilitarBtnProducto();        
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vistaProducto.jBGuardarProducto) {
            registrarProducto();
        } else if (e.getSource() == vistaProducto.jBActualizarProducto) {
            actualizarProducto();
        } else if (e.getSource() == vistaProducto.jBEliminarProducto) {
            eliminarProducto();
        } else if (e.getSource() == vistaProducto.jBBuscarProducto) {
            consultarProducto();
        } else if (e.getSource() == vistaProducto.jBLimpiar) {
            limpiarCampos();
            habilitarBtnProducto();           
        }  
    }
    
    public void registrarProducto() {
        String categoria = vistaProducto.jCCategoria.getSelectedItem().toString();
        String descripcion = vistaProducto.jTDescripcionProducto.getText();
        String nombre = vistaProducto.jTNombreProducto.getText();
        float precio = Float.parseFloat(vistaProducto.jTPrecioProducto.getText());
        
        modeloCategoria = new CategoriaProducto(0, categoria, descripcion);
        modeloCategoria.registrarCategoria();
        
        modeloProducto = new Producto(0, modeloCategoria.getIdCategoriaProducto(), nombre, precio);
        modeloProducto.registrarProducto();
        
        limpiarCampos();
        DefaultTableModel modeloTablaProducto = (DefaultTableModel) vistaProducto.jTProductos.getModel();
        modeloProducto.verDatosProducto(modeloTablaProducto);        
        JOptionPane.showMessageDialog(vistaProducto, 
                "Producto registrado correctamente", 
                "Éxito", 
                JOptionPane.INFORMATION_MESSAGE);
        habilitarBtnProducto();
        
    }
    
    public void consultarProducto() {
        String IDProducto = vistaProducto.jTidProducto.getText();

        if (IDProducto.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingrese el ID del Producto a consultar", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int idProducto = Integer.parseInt(IDProducto);
        
        Producto productoEncontrado = modeloProducto.consultarProducto(idProducto);

        if (productoEncontrado != null) {
            vistaProducto.jTNombreProducto.setText(productoEncontrado.getNombreProd());
            vistaProducto.jTPrecioProducto.setText(String.valueOf(productoEncontrado.getPrecioUnitario()));
            
            CategoriaProducto categoriaEncontrado = CategoriaProducto.consultarCategoria(productoEncontrado.getIdCategoriaProducto());            
            if (categoriaEncontrado != null) {
                vistaProducto.jCCategoria.setSelectedItem(categoriaEncontrado.getCategoriaProducto());
                vistaProducto.jTDescripcionProducto.setText(categoriaEncontrado.getDescripcionProducto());
            } else {
                JOptionPane.showMessageDialog(vistaProducto, "Error, no se encontró la categoria del producto con ID " + IDProducto + " ", "ERROR", JOptionPane.ERROR_MESSAGE);
            }
            
            deshabilitarBtnProducto();
        } else {
            JOptionPane.showMessageDialog(vistaProducto, "Error, el producto con ID " + IDProducto + " no se encuentra en la base de datos", "ERROR", JOptionPane.ERROR_MESSAGE);
        }        
    }
    public void eliminarProducto() {
        
        int idProducto = Integer.parseInt(vistaProducto.jTidProducto.getText());
        
        int confirmacion = JOptionPane.showConfirmDialog(null, "¿Está seguro de eliminar el curso?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if(confirmacion == JOptionPane.YES_OPTION){
            Producto productoEncontrado = modeloProducto.consultarProducto(idProducto);
            if(productoEncontrado!=null){
                productoEncontrado.eliminarProducto();
            } else {
                    JOptionPane.showMessageDialog(vistaProducto, "No se encontró el Producto con ID: " + idProducto, "Error", JOptionPane.ERROR_MESSAGE);
                    return;
            }
            
            CategoriaProducto categoriaEncontrado = CategoriaProducto.consultarCategoria(modeloProducto.getIdCategoriaProducto());
            if(categoriaEncontrado != null){
                categoriaEncontrado.eliminarCategoria();
            }
            limpiarCampos();
            DefaultTableModel modeloTablaProducto = (DefaultTableModel) vistaProducto.jTProductos.getModel();
            modeloProducto.verDatosProducto(modeloTablaProducto);   
            habilitarBtnProducto(); 
            JOptionPane.showMessageDialog(vistaProducto, "Producto eliminado exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);   
        }
    }
    
    public void actualizarProducto(){
        String categoria = vistaProducto.jCCategoria.getSelectedItem().toString();
        String descripcion = vistaProducto.jTDescripcionProducto.getText();
        String nombre = vistaProducto.jTNombreProducto.getText();
        float precio = Float.parseFloat(vistaProducto.jTPrecioProducto.getText());

        int idProducto = Integer.parseInt(vistaProducto.jTidProducto.getText()); 

        Producto productoEncontrado = modeloProducto.consultarProducto(idProducto);
        if(productoEncontrado != null){
            productoEncontrado.setNombreProd(nombre);
            productoEncontrado.setPrecioUnitario(precio);
            productoEncontrado.actualizarProducto();           
        }

        CategoriaProducto categoriaEncontrado = modeloCategoria.consultarCategoria(modeloProducto.getIdCategoriaProducto());
        if (categoriaEncontrado != null) {
            categoriaEncontrado.setCategoriaProducto(categoria);
            categoriaEncontrado.setDescripcionProducto(descripcion);
            categoriaEncontrado.actualizarCategoria();
        } 

        limpiarCampos();
        DefaultTableModel modeloTablaProducto = (DefaultTableModel) vistaProducto.jTProductos.getModel();
        modeloProducto.verDatosProducto(modeloTablaProducto);
        habilitarBtnProducto();                
        JOptionPane.showMessageDialog(vistaProducto, "Empleado actualizado exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);       
    }

    private void limpiarCampos() {
        vistaProducto.jTidProducto.setText("");
        vistaProducto.jTNombreProducto.setText("");
        vistaProducto.jTDescripcionProducto.setText("");
        vistaProducto.jTPrecioProducto.setText("");
        vistaProducto.jCCategoria.setSelectedIndex(0);
    }
    
    private void deshabilitarBtnProducto(){
        vistaProducto.jBGuardarProducto.setEnabled(false);
        vistaProducto.jBBuscarProducto.setEnabled(true);
        vistaProducto.jBEliminarProducto.setEnabled(true);
        vistaProducto.jBActualizarProducto.setEnabled(true);
    }
    
    private void habilitarBtnProducto(){
        vistaProducto.jBGuardarProducto.setEnabled(true);
        vistaProducto.jBBuscarProducto.setEnabled(true);
        vistaProducto.jBEliminarProducto.setEnabled(false);
        vistaProducto.jBActualizarProducto.setEnabled(false);
    }
}
