package SistemaMerysControlador;

import SistemaMerysModelo.CargoEmpleado;
import SistemaMerysModelo.Empleado;
import SistemaMerysModelo.Usuario;
import SistemaMerysVista.PagGestionarEmpleado;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class GestionarEmpleadoControl implements ActionListener {

    private PagGestionarEmpleado vistaEmpleado;
    private Empleado modeloEmpleado;
    private Usuario modeloUsuario;
    private CargoEmpleado modeloCargo;

    public GestionarEmpleadoControl(PagGestionarEmpleado vistaEmpleado, Empleado modeloEmpleado, Usuario modeloUsuario,CargoEmpleado modeloCargo) {
        this.vistaEmpleado = vistaEmpleado;
        this.modeloEmpleado = modeloEmpleado;
        this.modeloUsuario = modeloUsuario;
        this.modeloCargo = modeloCargo;
        this.vistaEmpleado.jBGuardarEmpleado.addActionListener(this);
        this.vistaEmpleado.jBActualizarEmpleado.addActionListener(this);
        this.vistaEmpleado.jBEliminarEmpleado.addActionListener(this);
        this.vistaEmpleado.jBBuscarEmpleado.addActionListener(this);        
        
    }

    public void iniciarEmpleado() {
        vistaEmpleado.setTitle("Gestión de Empleados");
        DefaultTableModel modeloTablaEmpleado = (DefaultTableModel) vistaEmpleado.jTEmpleados.getModel();
        modeloEmpleado.verDatosEmpleado(modeloTablaEmpleado);
        habilitarBtnEmpleados();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vistaEmpleado.jBGuardarEmpleado) {
            registrarEmpleado();
        } else if (e.getSource() == vistaEmpleado.jBActualizarEmpleado) {
            actualizarEmpleado();
        } else if (e.getSource() == vistaEmpleado.jBEliminarEmpleado) {
            eliminarEmpleado();
        } else if (e.getSource() == vistaEmpleado.jBBuscarEmpleado) {
            consultarEmpleado();
        }
    }

    private void registrarEmpleado() {
            // Obtener datos del formulario
        String nombre = vistaEmpleado.jTNombreEmpleado.getText();
        String apellido = vistaEmpleado.jTApellidoEmpleado.getText();
        String telefono = vistaEmpleado.jTTelefonoEmpleado.getText();
        int edad = Integer.parseInt(vistaEmpleado.jTEdadEmpleado.getText());
        String DNI = vistaEmpleado.jTDNIEmpleado.getText();
        String nombreUsuario = vistaEmpleado.jTNombreUsuario.getText();
        String contraseña = vistaEmpleado.jTContraseña.getText();
        String correo = vistaEmpleado.jTCorreoEmpleado.getText();
        String cargo = vistaEmpleado.jCCargo.getSelectedItem().toString();

        modeloUsuario = new Usuario(0, nombreUsuario, correo, contraseña);
        modeloUsuario.registrarUsuario();

        modeloCargo = new CargoEmpleado(0, cargo);
        modeloCargo.registrarCargoEmpleado();

        modeloEmpleado = new Empleado(0, modeloCargo.getIdCargoEmpleado(), modeloUsuario.getIdUsuario(), nombre, apellido, telefono, edad, DNI);
        modeloEmpleado.registrarEmpleado();

        limpiarCampos();

        DefaultTableModel modeloTablaEmpleado = (DefaultTableModel) vistaEmpleado.jTEmpleados.getModel();
        modeloEmpleado.verDatosEmpleado(modeloTablaEmpleado);            
        JOptionPane.showMessageDialog(vistaEmpleado, "Empleado registrado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        habilitarBtnEmpleados();
        }
    
    private void consultarEmpleado() {
        String IDEmpleado = vistaEmpleado.jTidEmpleado.getText();

        if (IDEmpleado.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingrese el ID del Empleado a consultar", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int idEmpleado = Integer.parseInt(IDEmpleado);
        Empleado empleadoEncontrado = modeloEmpleado.consultarEmpleado(idEmpleado);

        if (empleadoEncontrado != null) {
            vistaEmpleado.jTNombreEmpleado.setText(empleadoEncontrado.getNombre());
            vistaEmpleado.jTApellidoEmpleado.setText(empleadoEncontrado.getApellido());
            vistaEmpleado.jTTelefonoEmpleado.setText(empleadoEncontrado.getTelefono());
            vistaEmpleado.jTDNIEmpleado.setText(empleadoEncontrado.getDNI());
            vistaEmpleado.jTEdadEmpleado.setText(String.valueOf(empleadoEncontrado.getEdad()));
         
            CargoEmpleado cargoEncontrado = CargoEmpleado.consultarCargo(empleadoEncontrado.getIdCargoEmpleado());
            if (cargoEncontrado != null) {
                vistaEmpleado.jCCargo.setSelectedItem(cargoEncontrado.getCargoEmpleado());
            } else {
                JOptionPane.showMessageDialog(vistaEmpleado, "Error, no se encontró el cargo del empleado con ID [" + idEmpleado + "]", "ERROR", JOptionPane.ERROR_MESSAGE);
            }

            Usuario usuarioEncontrado = Usuario.consultarUsuario(empleadoEncontrado.getIdUsuario());
            if (usuarioEncontrado != null) {
                vistaEmpleado.jTNombreUsuario.setText(usuarioEncontrado.getNombre_usuario());
                vistaEmpleado.jTCorreoEmpleado.setText(usuarioEncontrado.getCorreo());
                vistaEmpleado.jTContraseña.setText(usuarioEncontrado.getContraseña());
            } else {
                JOptionPane.showMessageDialog(vistaEmpleado, "Error, no se encontró el usuario del empleado con ID [" + idEmpleado + "]", "ERROR", JOptionPane.ERROR_MESSAGE);
            }
            deshabilitarBtnEmpleados();
        } else {
            JOptionPane.showMessageDialog(vistaEmpleado, "Error, el empleado con ID [" + idEmpleado + "] no se encuentra en la base de datos", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void eliminarEmpleado() {
        
        int idEmpleado = Integer.parseInt(vistaEmpleado.jTidEmpleado.getText());

        int confirmacion = JOptionPane.showConfirmDialog(null, "¿Está seguro de eliminar el curso?", "Confirmación", JOptionPane.YES_NO_OPTION);
            if (confirmacion == JOptionPane.YES_OPTION) {
                Empleado empleadoEncontrado = modeloEmpleado.consultarEmpleado(idEmpleado);
                if (empleadoEncontrado != null) {
                    empleadoEncontrado.eliminarEmpleado();
                } else {
                    JOptionPane.showMessageDialog(vistaEmpleado, "No se encontró al empleado con ID: " + idEmpleado, "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                CargoEmpleado cargoEncontrado = CargoEmpleado.consultarCargo(empleadoEncontrado.getIdCargoEmpleado());
                if (cargoEncontrado != null) {
                    cargoEncontrado.eliminarCargoEmpleado();
                } 

                Usuario usuarioEncontrado = Usuario.consultarUsuario(empleadoEncontrado.getIdUsuario());
                if (usuarioEncontrado != null) {
                    usuarioEncontrado.eliminarUsuario();
                }

                limpiarCampos();

                DefaultTableModel modeloTablaEmpleado = (DefaultTableModel) vistaEmpleado.jTEmpleados.getModel();
                modeloEmpleado.verDatosEmpleado(modeloTablaEmpleado);
                habilitarBtnEmpleados();
                JOptionPane.showMessageDialog(vistaEmpleado, "Empleado eliminado exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);   
            }
    }
    
    public void actualizarEmpleado() {        
        String nombre = vistaEmpleado.jTNombreEmpleado.getText();
        String apellido = vistaEmpleado.jTApellidoEmpleado.getText();
        String telefono = vistaEmpleado.jTTelefonoEmpleado.getText();
        int edad = Integer.parseInt(vistaEmpleado.jTEdadEmpleado.getText());
        String DNI = vistaEmpleado.jTDNIEmpleado.getText();
        String nombreUsuario = vistaEmpleado.jTNombreUsuario.getText();
        String contraseña = vistaEmpleado.jTContraseña.getText();
        String correo = vistaEmpleado.jTCorreoEmpleado.getText();
        String cargo = vistaEmpleado.jCCargo.getSelectedItem().toString();

        int idEmpleado = Integer.parseInt(vistaEmpleado.jTidEmpleado.getText()); 

        Empleado empleadoEncontrado = modeloEmpleado.consultarEmpleado(idEmpleado);
        if(empleadoEncontrado != null){
            empleadoEncontrado.setNombre(nombre);
            empleadoEncontrado.setApellido(apellido);
            empleadoEncontrado.setTelefono(telefono);
            empleadoEncontrado.setEdad(edad);
            empleadoEncontrado.setDNI(DNI);
            empleadoEncontrado.actualizarEmpleado();           
        }

        Usuario usuarioEncontrado = modeloUsuario.consultarUsuario(modeloEmpleado.getIdUsuario());
        if (usuarioEncontrado != null) {
            usuarioEncontrado.setNombre_usuario(nombreUsuario);
            usuarioEncontrado.setCorreo(correo);
            usuarioEncontrado.setContraseña(contraseña);
            usuarioEncontrado.actualizarUsuario();
        }

        CargoEmpleado cargoEncontrado = modeloCargo.consultarCargo(modeloEmpleado.getIdCargoEmpleado());
        if (cargoEncontrado != null) {
            cargoEncontrado.setCargoEmpleado(cargo);
            cargoEncontrado.actualizarCargoEmpleado();
        } 

        limpiarCampos();
        DefaultTableModel modeloTablaEmpleado = (DefaultTableModel) vistaEmpleado.jTEmpleados.getModel();
        modeloEmpleado.verDatosEmpleado(modeloTablaEmpleado);
        habilitarBtnEmpleados();                
        JOptionPane.showMessageDialog(vistaEmpleado, "Empleado actualizado exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);                     
    }
    
    private void limpiarCampos() {
        vistaEmpleado.jTNombreEmpleado.setText("");
        vistaEmpleado.jTApellidoEmpleado.setText("");
        vistaEmpleado.jTTelefonoEmpleado.setText("");
        vistaEmpleado.jTCorreoEmpleado.setText("");
        vistaEmpleado.jTDNIEmpleado.setText("");
        vistaEmpleado.jTEdadEmpleado.setText("");
        vistaEmpleado.jTNombreUsuario.setText("");
        vistaEmpleado.jTContraseña.setText("");
        vistaEmpleado.jCCargo.setSelectedIndex(0);
    }
    
    private void deshabilitarBtnEmpleados(){
        vistaEmpleado.jBGuardarEmpleado.setEnabled(false);
        vistaEmpleado.jBBuscarEmpleado.setEnabled(true);
        vistaEmpleado.jBEliminarEmpleado.setEnabled(true);
        vistaEmpleado.jBActualizarEmpleado.setEnabled(true);
    }
    
    private void habilitarBtnEmpleados(){
        vistaEmpleado.jBGuardarEmpleado.setEnabled(true);
        vistaEmpleado.jBBuscarEmpleado.setEnabled(true);
        vistaEmpleado.jBEliminarEmpleado.setEnabled(false);
        vistaEmpleado.jBActualizarEmpleado.setEnabled(false);
    }
}
