package SistemaMerysControlador;

import SistemaMerysModelo.Empleado;
import SistemaMerysModelo.Login;
import SistemaMerysModelo.Usuario;
import SistemaMerysVista.PagGestionarPedido;
import SistemaMerysVista.PagLogin;
import SistemaMerysVista.PagMenuPrincipal;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import java.sql.SQLException;

public class LoginControlador implements ActionListener {
    
    private Login modelologin;
    private PagLogin vistaLogin;

    public LoginControlador(PagLogin vistaLogin, Login modelologin) {
        this.modelologin = modelologin;
        this.vistaLogin = vistaLogin;
        this.vistaLogin.btnIngresar.addActionListener(this);
        this.vistaLogin.CheckMostrarContra.addActionListener(this); // Agregar listener para CheckMostrarContra
    }
    
    public void iniciarLogin() {
        vistaLogin.setVisible(true);
        vistaLogin.setTitle("Ingresar Login");
        vistaLogin.setLocationRelativeTo(null);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vistaLogin.btnIngresar) {
            IngresarLogin();
        } else if (e.getSource() == vistaLogin.CheckMostrarContra) {
            CheckMostrarContraseña();
        } 
    }
     
   private void IngresarLogin() {
        String usuario = vistaLogin.txtUsuario.getText();
        String contraseña = new String(vistaLogin.txtContraseña.getPassword());

        try {
            Usuario usuarioObj = modelologin.validarLogin(usuario, contraseña);
            if (usuarioObj != null) {
                Empleado empleado = modelologin.obtenerEmpleadoPorIdUsuario(usuarioObj.getIdUsuario());
                if (empleado != null) {
                    String cargo = modelologin.obtenerCargoPorIdCargoEmpleado(empleado.getIdCargoEmpleado());
                    if (cargo != null) {
                        JOptionPane.showMessageDialog(null, "Inicio de sesión exitoso.");
                        PagMenuPrincipal menuPrincipal = new PagMenuPrincipal(cargo,empleado);
                        menuPrincipal.setVisible(true);
                        vistaLogin.dispose();
                    } else {
                        JOptionPane.showMessageDialog(null, "Cargo no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Empleado no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void CheckMostrarContraseña() {
        if (vistaLogin.CheckMostrarContra.isSelected()) {
            vistaLogin.txtContraseña.setEchoChar((char) 0);
        } else {
            vistaLogin.txtContraseña.setEchoChar('*');
        }
    }
    
    
}
