package SistemaMerysControlador;

import SistemaMerysModelo.Boleta;
import SistemaMerysModelo.Cliente;
import SistemaMerysModelo.DetallePedido;
import SistemaMerysModelo.Direccion;
import SistemaMerysModelo.Empleado;
import SistemaMerysModelo.Pedido;
import SistemaMerysModelo.Producto;
import SistemaMerysVista.PagAgregarCliente;
import SistemaMerysVista.PagGestionarPedido;
import SistemaMerysVista.SeleccionarCantidad;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class GestionarPedidoControl implements ActionListener {
    
    private PagGestionarPedido vistaPedido;
    private PagAgregarCliente vistaCliente;
    private Pedido modeloPedido;
    private Direccion modeloDireccion;
    private Producto modeloProducto;
    private DetallePedido modeloDetalle;
    private Cliente modeloCliente;
    private Empleado modeloEmpleado;
    private Boleta modeloBoleta;
    private String[] datosCliente; // Array para almacenar datos del cliente
    private int idProductoSeleccionado;
    private int cantidadSeleccionada;
    private int cantidadProductos; 

    public GestionarPedidoControl(PagGestionarPedido vistaPedido, Pedido modeloPedido, Producto modeloProducto, 
            DetallePedido modeloDetalle, Cliente modeloCliente, Empleado modeloEmpleado, Boleta modeloBoleta) {
        this.vistaPedido = vistaPedido;
        this.modeloPedido = modeloPedido;
        this.modeloProducto = modeloProducto;
        this.modeloDetalle = modeloDetalle;
        this.modeloCliente = modeloCliente;
        this.modeloEmpleado = modeloEmpleado;
        this.modeloBoleta = modeloBoleta;

        
        // Asigna los listeners a los botones u otros componentes según sea necesario
        this.vistaPedido.jBProcesar.addActionListener(this);
        this.vistaPedido.jBEliminar.addActionListener(this);
        this.vistaPedido.jBCliente.addActionListener(this);
        this.vistaPedido.jBProducto1.addActionListener(this);
        this.vistaPedido.jBProducto2.addActionListener(this);
        this.vistaPedido.jBProducto3.addActionListener(this);
        this.vistaPedido.jBProducto4.addActionListener(this);
    }
    
    public void iniciarPedido(){ 
        vistaPedido.setTitle("Gestión de Pedido");
        mostrarProductos();
        vistaPedido.jLFecha.setText(fechaActual());
        DefaultTableModel modeloTablaCarrito = (DefaultTableModel) vistaPedido.jTCarritoPedido.getModel();
        modeloPedido.verDatosCarrito(modeloTablaCarrito);
        DefaultTableModel verDatosPedidosDisponibles = (DefaultTableModel) vistaPedido.jTPedidosDisponibles.getModel();
        modeloPedido.verDatosPedidosDisponibles(verDatosPedidosDisponibles);       
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vistaPedido.jBProcesar) {
            procesarPedido();
        } else if (e.getSource() == vistaPedido.jBActualizarPedido) {
            actualizarPedido();
        } else if (e.getSource() == vistaPedido.jBCliente) {
            gestionarCliente();
        } else if (e.getSource() == vistaPedido.jBProducto1) {
            idProductoSeleccionado=18;
            SeleccionarCantidad();
            System.out.println("Producto seleccionado: " + idProductoSeleccionado);
        } else if (e.getSource() == vistaPedido.jBProducto2) {
            idProductoSeleccionado=19; 
            System.out.println("Producto seleccionado: " + idProductoSeleccionado);
        } else if (e.getSource() == vistaPedido.jBProducto3) {
            idProductoSeleccionado=20;
            SeleccionarCantidad();
            System.out.println("Producto seleccionado: " + idProductoSeleccionado);
        } else if (e.getSource() == vistaPedido.jBProducto4) {
            idProductoSeleccionado=21;
            SeleccionarCantidad();
            System.out.println("Producto seleccionado: " + idProductoSeleccionado);
        }
    }
    
    public void gestionarCliente() {
        vistaCliente = new PagAgregarCliente(this);
        vistaCliente.setVisible(true);
        vistaCliente.setLocationRelativeTo(null);
    }

    public void recibirDatosCliente() {

    }

    public void SeleccionarCantidad() {
        SeleccionarCantidad seleccionarCantidad = new SeleccionarCantidad(this);
        seleccionarCantidad.setVisible(true);
        seleccionarCantidad.setLocationRelativeTo(null);
    }

    public void recibirCantidad(int cantidad) {
        this.cantidadProductos = cantidad;
    }

    public void procesarPedido() {
        if (idProductoSeleccionado == 0 || cantidadProductos == 0) {
            JOptionPane.showMessageDialog(vistaPedido, "Debe seleccionar al menos un producto y una cantidad.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String fecha = fechaActual();
        String estado = vistaPedido.jLEstadoPedido.getText();
        String descripcionPedido = vistaPedido.jTDescripcion.getText();
        String tipo = vistaPedido.jCTipoPedido.getSelectedItem().toString();
        int numMesa = Integer.parseInt(vistaPedido.jTNumMesa.getText());

        String[] datosCliente = vistaCliente.obtenerDatosCliente();
        String nombre = datosCliente[0];
        String apellido = datosCliente[1];
        String telefono = datosCliente[2];
        String calle = datosCliente[3];
        String descripcion = datosCliente[4];
        String distrito = datosCliente[5];

        Direccion direccionEncontrado = new Direccion(0, calle, descripcion, distrito);
        direccionEncontrado.registrarDireccion();
        
        Cliente clienteEncontrado = new Cliente(0, direccionEncontrado.getIdDireccion(), nombre, apellido, telefono);
        clienteEncontrado.registrarCliente();
        
        Producto productoEncontrado = modeloProducto.consultarProducto(idProductoSeleccionado);                   
        double total = cantidadProductos * productoEncontrado.getPrecioUnitario();
        Pedido pedidoEncontrado = new Pedido(0, productoEncontrado.getIdProducto(), vistaPedido.getIdEmpleado(), clienteEncontrado.getIdCliente(),
                            fecha, numMesa, estado, descripcionPedido, tipo, cantidadProductos, (float) total);
        pedidoEncontrado.registrarPedido();
        
        DefaultTableModel modeloTablaCarrito = (DefaultTableModel) vistaPedido.jTCarritoPedido.getModel();
        modeloPedido.verDatosCarrito(modeloTablaCarrito);
        
        DefaultTableModel verDatosPedidosDisponibles = (DefaultTableModel) vistaPedido.jTPedidosDisponibles.getModel();
        modeloPedido.verDatosPedidosDisponibles(verDatosPedidosDisponibles);
        
    }


public void finalizarPedido() {
    if (idProductoSeleccionado == 0 || cantidadProductos == 0) {
        JOptionPane.showMessageDialog(vistaPedido, "Debe seleccionar al menos un producto y una cantidad.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Obtener datos del cliente
    String[] datosCliente = vistaCliente.obtenerDatosCliente();
    String nombre = datosCliente[0];
    String apellido = datosCliente[1];
    String telefono = datosCliente[2];
    String calle = datosCliente[3];
    String descripcion = datosCliente[4];
    String distrito = datosCliente[5];

    // Registrar dirección y cliente si no existen
    Direccion direccionEncontrado = new Direccion(0, calle, descripcion, distrito);
    direccionEncontrado.registrarDireccion();

    Cliente clienteEncontrado = new Cliente(0, direccionEncontrado.getIdDireccion(), nombre, apellido, telefono);
    clienteEncontrado.registrarCliente();

    // Calcular cantidad total de productos y total
    int cantidadTotalProductos = calcularCantidadTotalProductos();
    double total = calcularTotalPedido();

    // Registrar detalle del pedido
    DetallePedido detallePedido = new DetallePedido(0, modeloPedido.getIdPedido(), cantidadTotalProductos, (float) total);
    detallePedido.registrarDetallePedido();

    // Limpiar carrito o realizar otras acciones necesarias
    limpiarCarrito();
    // Otras acciones después de finalizar el pedido

    // Actualizar la interfaz o mostrar mensaje de éxito
    JOptionPane.showMessageDialog(vistaPedido, "Pedido finalizado correctamente.", "Información", JOptionPane.INFORMATION_MESSAGE);
}

    private int calcularCantidadTotalProductos() {
        // Lógica para calcular la cantidad total de productos en el carrito
        return cantidadProductos;
    }

    private double calcularTotalPedido() {
        // Lógica para calcular el total del pedido
        // Puedes usar los modelos de producto y el carrito para calcular esto
        double total = 0.0;
        // Por ejemplo, sumar el precio unitario de cada producto por la cantidad
        // Recorre el carrito y suma los precios unitarios multiplicados por la cantidad
        return total;
    }

    private void limpiarCarrito() {
        DefaultTableModel modeloTablaCarrito = (DefaultTableModel) vistaPedido.jTCarritoPedido.getModel();
        modeloTablaCarrito.setRowCount(0); // Limpiar el modelo de la tabla
        // Otras acciones para limpiar el carrito en la interfaz
    }

   
   
    public void manejarSeleccionProducto(int idProducto) {
        Producto productoEncontrado = modeloProducto.consultarProducto(idProducto);
        if (productoEncontrado != null) {
            System.out.println("Producto seleccionado: " + productoEncontrado.getNombreProd());
        } else {
            JOptionPane.showMessageDialog(vistaPedido, "No se encontró el producto con id " + idProducto, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
     
    public void actualizarPedido() {
        // Lógica para actualizar el pedido
    }
    
    private void mostrarProductos() {
        Producto productoModel = new Producto();
        Producto primerProducto = productoModel.consultarProducto(18);
        Producto segundoProducto = productoModel.consultarProducto(19);
        Producto tercerProducto = productoModel.consultarProducto(20);
        Producto cuartoProducto = productoModel.consultarProducto(21);
        
        if (primerProducto != null) {
            vistaPedido.jLProducto1.setText(primerProducto.getNombreProd());
            vistaPedido.jLPrecio1.setText(String.valueOf("S/" + primerProducto.getPrecioUnitario()));
        } 
        if (segundoProducto != null) {
            vistaPedido.jLProducto2.setText(segundoProducto.getNombreProd());
            vistaPedido.jLPrecio2.setText(String.valueOf("S/" + segundoProducto.getPrecioUnitario()));
        } 
        if (tercerProducto != null) {
            vistaPedido.jLProducto3.setText(tercerProducto.getNombreProd());
            vistaPedido.jLPrecio3.setText(String.valueOf("S/" + tercerProducto.getPrecioUnitario()));
        } 
        if (cuartoProducto != null) {
            vistaPedido.jLProducto4.setText(cuartoProducto.getNombreProd());
            vistaPedido.jLPrecio4.setText(String.valueOf("S/" + cuartoProducto.getPrecioUnitario()));
        }         
        else {
            vistaPedido.jLProducto1.setText("No hay productos");
            vistaPedido.jLPrecio1.setText("");
        }
    }
   
    public static String fechaActual(){   
        Date fecha=new Date();
        SimpleDateFormat formatoFecha=new SimpleDateFormat("dd/MM/YYYY");   
        return formatoFecha.format(fecha);
    }
}
